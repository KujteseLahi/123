        
        
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Insert Market</title>
    <link rel="stylesheet" href="css/style.css" />
</head>

<body>
    <div class="form-group">
        <div class="form-header">
            <h2>Market Register</h2>
        </div>
        <form action="insertMarketView.php" method="post"enctype="multipart/form-data">
            <input type="text" name="MarketName" placeholder="Market Name" />
            <input type="text" name="Address" placeholder="Address" />
            <input type="text" name="Phone" placeholder="Phone" />
           
            <input type="submit" name="submitbtn" value="Register" />
        </form>
    </div>
</body>

</html>

    

    