        
        
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Insert Product</title>
    <link rel="stylesheet" href="css/style.css" />
</head>

<body>
    <div class="form-group">
        <div class="form-header">
            <h2>Offers Slider Register</h2>
        </div>
        <form action="insertSliderMarketView.php" method="post"enctype="multipart/form-data">
          
            <input type="file" name="SliderMarketPicPath" accept="image/x-png,image/gif,image/jpeg" placeholder="Offers Picture" />
         
            <input type="submit" name="submitbtn" value="Register" />
        </form>
    </div>
</body>

</html>

    

    